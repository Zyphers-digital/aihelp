const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');
const { Configuration, OpenAIApi } = require('openai');

const app = express();
const port = 3000;

app.use(cors());
app.use(bodyParser.json());

const configuration = new Configuration({
  apiKey: process.env.OPENAI_API_KEY,
});
const openai = new OpenAIApi(configuration);

app.post('/api/gpt', async (req, res) => {
  const prompt = req.body.prompt;
  try {
    const completion = await openai.createChatCompletion({
      model: 'gpt-4',
      messages: [{ role: 'user', content: prompt }],
    });
    res.json({ result: completion.data.choices[0].message.content });
  } catch (error) {
    console.error('GPT-feil:', error.response?.data || error.message);
    res.status(500).send('Feil i GPT-forespørsel.');
  }
});

app.get('/', (req, res) => {
  res.send('🟢 AIPlan-backend kjører!');
});

app.listen(port, () => {
  console.log(`🚀 Server kjører på http://localhost:${port}`);
});